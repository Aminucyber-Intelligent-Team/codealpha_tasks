# Bank Account Management System

**Name:** Aminu Hussaini Nuhu
**Student ID:** CA/DF1/317533
**Internship:** Java Programming Intern at CodeAlpha (10 Oct 2026 - 10 Nov 2026)

## Description
A console-based banking application written in Java using Object-Oriented Programming.

## Features
- Create an account (name, account number, initial deposit)
- Check balance and account details
- Deposit and withdraw money
- Transaction history with date and time
- Input validation (no negative amounts, no letters, no overdraft)

## Project Structure
```
BankAccountSystem/
├── src/
│   ├── Main.java          (menu and user input)
│   ├── BankAccount.java   (account logic)
│   └── Transaction.java   (transaction record)
└── README.md
```

## How to Run
```
cd src
javac *.java
java Main
```
Requires JDK 8 or newer.

## OOP Concepts Used
Encapsulation (private fields), classes and objects, constructors, exception handling, collections (ArrayList).
