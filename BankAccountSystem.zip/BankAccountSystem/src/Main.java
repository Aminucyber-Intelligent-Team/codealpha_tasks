import java.util.Scanner;

public class Main {

    private static double readAmount(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a valid number.");
            }
        }
    }

    private static int readChoice(Scanner scanner) {
        while (true) {
            System.out.print("Your Choice: ");
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number from the menu.");
            }
        }
    }

    private static BankAccount createAccount(Scanner scanner) {
        while (true) {
            System.out.print("Enter Account Holder Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Account Number: ");
            String accNum = scanner.nextLine();
            double initial = readAmount(scanner, "Enter Initial Deposit: ");
            try {
                return new BankAccount(accNum, name, initial);
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage() + " Please try again.\n");
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== BANK ACCOUNT MANAGEMENT SYSTEM ===");
        BankAccount account = createAccount(scanner);
        System.out.println("\nAccount created successfully!");

        boolean running = true;
        while (running) {
            System.out.println("\n--- Select Option ---");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Transaction History");
            System.out.println("5. Exit");

            int choice = readChoice(scanner);
            try {
                switch (choice) {
                    case 1:
                        account.displayAccountDetails();
                        break;
                    case 2:
                        account.deposit(readAmount(scanner, "Enter amount to deposit: "));
                        System.out.printf("Deposit successful. Current Balance: $%.2f%n", account.getBalance());
                        break;
                    case 3:
                        account.withdraw(readAmount(scanner, "Enter amount to withdraw: "));
                        System.out.printf("Withdrawal successful. Remaining Balance: $%.2f%n", account.getBalance());
                        break;
                    case 4:
                        account.displayTransactionHistory();
                        break;
                    case 5:
                        running = false;
                        System.out.println("Exiting the system. Have a great day!");
                        break;
                    default:
                        System.out.println("Invalid choice, please try again.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        scanner.close();
    }
}
